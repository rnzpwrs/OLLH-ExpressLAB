<?php
	header('location:index.php');
?>
<!DOCTYPE html>
<html lang="en">
<script src="assets/js/browser-validation.js"></script>

</html>