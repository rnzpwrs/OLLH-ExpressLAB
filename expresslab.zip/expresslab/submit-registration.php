<?php 
	include('php/dbconn.php');
	include('assets/js/browser-validation.js');


	if(isset($_POST['submit'])) {
		/* Personal Information */
		$first_name = mysqli_real_escape_string($mysqli, $_POST['first_name']);
		$middle_name = mysqli_real_escape_string($mysqli, $_POST['middle_name']);
		$last_name = mysqli_real_escape_string($mysqli, $_POST['last_name']);
		$fullname = $last_name.', '.$first_name.' '.$middle_name;
		$suffix = mysqli_real_escape_string($mysqli, $_POST['suffix']);
		$sex = mysqli_real_escape_string($mysqli, $_POST['sex']);
		$birth_date = date("Y-m-d", strtotime($_POST['birth_date']));
		$civil_status = $_POST['civil_status'];
		/* Personal Information */

		/* Home Address */
		$region = mysqli_real_escape_string($mysqli, $_POST['region']);
		$province = mysqli_real_escape_string($mysqli, $_POST['province']);
		$getProvincePK = mysqli_query($mysqli,"SELECT * FROM aprovince WHERE province_code = '$province'");
		$rowGetProvincePK = mysqli_fetch_array($getProvincePK);
		$province = $rowGetProvincePK['PK_aprovince'];
		$municity = mysqli_real_escape_string($mysqli, $_POST['municity']);
		$barangay = mysqli_real_escape_string($mysqli, strtoupper($_POST['barangay']));
		$street = mysqli_real_escape_string($mysqli, strtoupper($_POST['street']));
		/* Home Address */

		/* Contact Information */
		$email_address = mysqli_real_escape_string($mysqli, $_POST['email_address']);
		$mobile_number = $_POST['mobile_number'];
		/* Contact Information */

		if($insertDatacenter = mysqli_query($mysqli,"INSERT INTO datacenter (
			fullname,
			lastname,
			firstname,
			middlename,
			suffix,
			birthdate,
			FK_pdcivilstatus,
			sex,
			mobile_number,
			telephone_number,
			email_address,
			FK_aregion,
			FK_aprovince,
			FK_amunicity,
			barangay,
			street) VALUES (
			'$fullname',
			'$last_name',
			'$first_name',
			'$middle_name',
			'$suffix',
			'$birth_date',
			'$civil_status',
			'$sex',
			'$mobile_number',
			'',
			'$email_address',
			'$region',
			'$province',
			'$municity',
			'$barangay',
			'$street'
			)")) {
				$PK_datacenter = mysqli_insert_id($mysqli);
				$registrydate = date("Y-m-d H:i:s");
				$uniqid = md5(uniqid());
				$insertPatregisters = mysqli_query($mysqli,"INSERT INTO patregisters (
					FK_datacenter,
					uniqid,
					email_address,
					registrydate) VALUES (
					'$PK_datacenter',
					'$uniqid',
					'$email_address',
					'$registrydate')");
				session_unset();
				session_destroy();
				header('location: done.php');	
		} else {
			die( mysqli_error($mysqli));
		}	
	}
?>
<!DOCTYPE html>
<html lang="en">
<?php include('assets/js/browser-validation.js'); ?>
</html>
