<?php include('php/dbconn.php'); ?>
<?php
  session_start();
  $_SESSION['session'] = "active";
  $pageSession = $_SESSION['session'];  
  $queryRegion = mysqli_query($mysqli,"SELECT * FROM aregion");
  $querySex = mysqli_query($mysqli,"SELECT * FROM pdsex WHERE isdefault = 1");
  $queryCivilStatus = mysqli_query($mysqli,"SELECT * FROM pdcivilstatus WHERE isdefault = 1");
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    
    <style>
body {
}

.card {
    padding: 30px 40px;
    margin-top: 60px;
    margin-bottom: 60px;
    border: none !important;
    box-shadow: 0 6px 12px 0 rgba(0, 0, 0, 0.2)
}

.blue-text {
    color: #00BCD4
}

.form-control-label {
    margin-bottom: 0
}

input,
textarea,
button {
    padding: 8px 15px;
    border-radius: 5px !important;
    margin: 5px 0px;
    box-sizing: border-box;
    border: 1px solid #ccc;
    font-size: 18px !important;
    font-weight: 300
}

select {
    padding: 8px 15px;
    border-radius: 5px !important;
    margin: 5px 0px;
    box-sizing: border-box;
    border: 1px solid #ccc;
    font-size: 18px !important;
    font-weight: 300
}

input:focus,
textarea:focus {
    -moz-box-shadow: none !important;
    -webkit-box-shadow: none !important;
    box-shadow: none !important;
    border: 1px solid #00BCD4;
    outline-width: 0;
    font-weight: 400
}

.btn-block {
    text-transform: uppercase;
    font-size: 15px !important;
    font-weight: 400;
    height: 43px;
    cursor: pointer
}

.btn-block:hover {
    color: #fff !important
}

button:focus {
    -moz-box-shadow: none !important;
    -webkit-box-shadow: none !important;
    box-shadow: none !important;
    outline-width: 0
}
    </style>
    <title>Hello, world!</title>
  </head>
  <body>
    <div class="container-fluid">
      <div class="container-fluid px-1 py-5 mx-auto">
          <div class="row d-flex justify-content-center">
              <div class="col-xl-7 col-lg-8 col-md-9 col-11 text-center">
                <img src="assets/img/expresslab-logo.png" class="img-fluid">
                  <h3>Registration</h3>
                  <div class="card">
                      <h5 class="text-left mb-4">Personal Information</h5>
                      <form class="form-card" method="POST" action="submit-registration.php">
                          <div class="row justify-content-between text-left">
                            <div class="form-group col-lg-4 col-md-6 col-sm-6 flex-column d-flex">
                              <label class="form-control-label px-3">First name<span class="text-danger"> *</span></label> 
                              <input type="text" id="fname" class="form-control" name="first_name" placeholder="First Name" style="text-transform:uppercase" onblur="validate(1)" required> 
                            </div>
                            <div class="form-group col-lg-4 col-md-6 col-sm-6 flex-column d-flex">
                              <label class="form-control-label px-3">Middle name</label> 
                              <input type="text" id="fname" class="form-control" name="middle_name" placeholder="Middle Name" style="text-transform:uppercase" onblur="validate(1)" required> 
                            </div>                        
                            <div class="form-group col-lg-4 col-md-8 col-sm-12 flex-column d-flex"> 
                              <label class="form-control-label px-3">Last name<span class="text-danger"> *</span></label> 
                              <input type="text" id="lname" class="form-control" name="last_name" placeholder="Last Name" style="text-transform:uppercase" onblur="validate(2)" required> 
                            </div>
                            <div class="form-group col-lg-6 col-md-4 col-sm-12 flex-column d-flex"> 
                              <label class="form-control-label px-3">Suffix<span class="text-danger"> *</span></label> 
                              <select name="suffix" class="form-control">
                                <option value="N/A" hidden selected>N/A (Not Applicable)</option>
                                <option value="N/A">N/A (Not Applicable)</option>
                                <option value="JR">JR.</option>
                                <option value="SR">SR.</option>
                                <option value="II">II</option>
                                <option value="III">III</option>
                                <option value="IV">IV</option>
                                <option value="V">V</option>                          
                              </select>
                            </div>                      
                            <div class="form-group col-md-6 col-sm-6 flex-column d-flex"> 
                              <label class="form-control-label px-3">Sex<span class="text-danger"> *</span></label> 
                              <select name="sex" class="form-control" required>
                                <option value="" hidden selected>- SELECT -</option>
                                <?php while($getRowSex = mysqli_fetch_array($querySex)) {?>
                                <option value="<?php echo $getRowSex['PK_pdsex'];?>"><?php echo $getRowSex['description'];?></option>
                                <?php } ?>
                              </select>
                            </div>   
                            <div class="form-group col-md-6 col-sm-6 flex-column d-flex"> 
                              <label class="form-control-label px-3">Birthdate<span class="text-danger"> *</span></label> 
                              <input type="date" id="lname" name="birth_date" max="<?php echo date("Y-m-d");?>" placeholder="Enter your last name" style="text-transform:uppercase" onblur="validate(2)"> 
                            </div>  
                            <div class="form-group col-md-6 col-sm-6 flex-column d-flex"> 
                              <label class="form-control-label px-3">Civil Status<span class="text-danger"> *</span></label> 
                                <select name="civil_status" class="form-control" required>
                                <?php while($getRowCivilStatus = mysqli_fetch_array($queryCivilStatus)) {?>
                                <option value="" hidden selected>- SELECT -</option>
                                <option value="<?php echo $getRowCivilStatus['PK_pdcivilstatus'];?>"><?php echo $getRowCivilStatus['description'];?></option>
                                <?php } ?>
                                </select>
                            </div>
                          </div>
                          <h5 class="text-left mb-4">Home Address</h5>                                          
                          <div class="row justify-content-between text-left">                      
                            <div class="form-group col-md-4 col-sm-4 flex-column d-flex">
                              <!-- Modal -->
                              <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog ">
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      <h5 class="modal-title" id="exampleModalLabel">Districts of Metro Manila</h5>
                                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                      </button>
                                    </div>
                                    <div class="modal-body text-center" style="padding:10px;">
                                      <a href="https://en.wikipedia.org/wiki/Category:Districts_in_Metro_Manila" target="_blank">
                                        <img class="img-fluid" src="assets/img/address-source.png">
                                      </a>
                                      <i><br><br><a href="https://en.wikipedia.org/wiki/Category:Districts_in_Metro_Manila" target="_blank">Source: Wikipedia</a><br></i>
                                    </div>
                                    <div class="modal-footer">
                                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>                               
                                    </div>
                                  </div>
                                </div>
                              </div>                        
                            </div>
                          </div>                    
                          <div class="row justify-content-between text-left">
                            <div class="form-group col-lg-6 col-md-12 col-sm-12 flex-column d-flex"> 
                              <label class="form-control-label px-3">Region<span class="text-danger"> *</span></label> 
                              <select id="region" name="region" class="form-control" required>
                                <option value="" hidden selected>- SELECT REGION -</option>
                                <?php while($getRowRegion = mysqli_fetch_array($queryRegion)) { ?>
                                  <option value="<?php echo $getRowRegion['PK_aregion']; ?>"><?php echo $getRowRegion['description']; ?></option>
                                <?php } ?>
                              </select>
                            </div>  
                            <div class="form-group col-lg-6 col-md-12 col-sm-12 flex-column d-flex"> 
                              <label class="form-control-label px-3">Province/District<span class="text-danger"> *</span><!-- Button trigger modal -->
                              <img src="assets/img/help.png" data-toggle="modal" data-target="#exampleModal"></label> 
                              <select id="province" name="province" class="form-control" required>
                              </select>
                            </div>   
                            <div class="form-group col-lg-6 col-md-12 col-sm-12 flex-column d-flex"> 
                              <label class="form-control-label px-3">Municipality<span class="text-danger"> *</span></label> 
                              <select id="municity" name="municity" class="form-control" required>                                
                              </select>
                            </div>  
                            <div class="form-group col-lg-6 col-md-12 col-sm-12 flex-column d-flex"> 
                              <label class="form-control-label px-3">Barangay<span class="text-danger"> *</span></label> 
                              <input type="text" id="barangay" name="barangay" placeholder="Barangay" style="text-transform:uppercase" onblur="validate(2)"> 
                            </div>
                            <div class="form-group col-lg-12 col-md-12 col-sm-12 flex-column d-flex"> 
                              <label class="form-control-label px-3">House No./Building No./Lot/Street Name</label> 
                              <input type="text" id="street" name="street" placeholder="House No./Building No./Lot/Street Name" style="text-transform:uppercase" onblur="validate(2)"> 
                            </div>
                          </div>
                          <h5 class="text-left mb-4">Contact Information</h5>                                                                 
                            <div class="row justify-content-between text-left">
                              <div class="form-group col-lg-6 col-md-12 col-sm-12 flex-column d-flex"> 
                                <label class="form-control-label px-3">Email Address<span class="text-danger"> *</span></label> 
                                <input type="email" id="lname" name="email_address" placeholder="Email Address" onblur="validate(2)"> 
                              </div> 
                            <div class="form-group col-lg-6 col-md-12 col-sm-12 flex-column d-flex"> 
                              <label class="form-control-label px-3">Mobile Number<span class="text-danger"> *</span></label> 
                              <input type="number" id="lname" name="mobile_number" placeholder="Mobile Number" onblur="validate(2)"> 
                            </div> 
                            <!-- <div class="form-group col-md-6 col-sm-6 flex-column d-flex"> 
                              <label class="form-control-label px-3">Telephone Number<span class="text-danger"> *</span></label> 
                              <input type="email" id="lname" name="lname" placeholder="Enter your last name" onblur="validate(2)"> 
                            </div> -->                                                                                                                                    
                            </div>
                            <hr>
                            <div class="row justify-content-between text-center">
                              <div class="form-group col-lg-12 col-md-12 col-sm-12 flex-column d-flex"> 
                                <input type="submit" name="submit" class="btn btn-success">
                              </div>                                                                                                                                 
                            </div>                            
                      </form>
                  </div>
              </div>
          </div>
      </div>
    </div>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!--<script src="assets/js/browser-validation.js"></script>-->
    <script>
    $(document).ready(function(){
        $('#region').on('change', function(){
            var regionID = $(this).val();
            if(regionID){
                $.ajax({
                    type:'POST',
                    url:'php/ajaxAddressData.php',
                    data:'region='+regionID,
                    success:function(html){
                        $('#province').html(html);
                        $('#municity').html('<option value="">- SELECT PROVINCE FIRST -</option>'); 
                    }
                }); 
            }else{
                $('#state').html('<option value="">Select country first</option>');
                $('#city').html('<option value="">Select state first</option>'); 
            }
        });
        
        $('#province').on('change', function(){
            var stateID = $(this).val();
            if(stateID){
                $.ajax({
                    type:'POST',
                    url:'php/ajaxAddressData.php',
                    data:'province='+stateID,
                    success:function(html){
                        $('#municity').html(html);
                    }
                }); 
            }else{
                $('#province').html('<option value="">SELECT PROVINCE FIRST</option>'); 
            }
        });
        $('#province').html('<option value="">- SELECT REGION FIRST -</option>'); 
        $('#municity').html('<option value="">- SELECT PROVINCE/DISTRICT FIRST -</option>'); 
    });
    </script>
    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.min.js" integrity="sha384-VHvPCCyXqtD5DqJeNxl2dtTyhF78xXNXdkwX1CZeRusQfRKp+tA7hAShOK/B/fQ2" crossorigin="anonymous"></script>
    -->
  </body>
</html>