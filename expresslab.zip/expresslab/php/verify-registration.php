<?php
	include_once('dbconn.php');

	$id = mysqli_real_escape_string($mysqli, $_GET['id']);
	$queryValidateID = mysqli_query($mysqli,"SELECT PK_patregisters,uniqid, status, isemailed, verifiedflag, cancelflag FROM patregisters
	WHERE isemailed = '1'
	AND cancelflag = '0'");

	while($rowValidateID = mysqli_fetch_array($queryValidateID)) {
		$PK_patregisters = $rowValidateID['PK_patregisters'];
		if(mysqli_real_escape_string($mysqli, md5($rowValidateID['uniqid'])) == $id && $rowValidateID['verifiedflag'] == '0' && $rowValidateID['isemailed'] == '1' && $rowValidateID['status'] == '1') {
			echo "<br>";
			echo "
			<!DOCTYPE html>
			<html lang='en'>
			<script src='../assets/js/browser-validation.js'></script>
			<script src='../assets/js/sweetalert.js'></script>
			<script>
				Swal.fire({
				  icon: 'success',
				  title: 'Verified Email Address <br>and Registration',
				  html: 'Please check your inbox ..',  
				  showConfirmButton: false,
				  timerProgressBar: true,
				  timer: 5000			  
				}).then(function() {
				     window.location.href = 'https://ollh-manila.com';
				})
			</script>
			</html>";
			$verifieddate = date("Y-m-d H:i:s");
			$updatePatregisters = mysqli_query($mysqli,"UPDATE patregisters SET status = '2', verifiedflag = '1', verifieddate = '$verifieddate' WHERE PK_patregisters = '$PK_patregisters'");			
		} else if(mysqli_real_escape_string($mysqli, md5($rowValidateID['uniqid'])) == $id && $rowValidateID['verifiedflag'] == '1' && $rowValidateID['cancelflag'] == '0' && $rowValidateID['status'] == '2') {
			echo "<br>";
			echo "
				<!DOCTYPE html>
				<html lang='en'>
				<script src='../assets/js/browser-validation.js'></script>
				<script src='../assets/js/sweetalert.js'></script>
				<script>
					Swal.fire({
					  icon: 'warning',
					  title: 'You are already verified!',
					  html: 'Please check your inbox ..',  
					  showConfirmButton: false,
					  timerProgressBar: true,
					  timer: 5000			  
					}).then(function() {
					     window.location.href = 'https://ollh-manila.com';
					})
				</script>
				</html>
			";
		} else {
			echo "<br>";
			echo "
			<!DOCTYPE html>
			<html lang='en'>
			<script src='../assets/js/browser-validation.js'></script>
			<script src='../assets/js/sweetalert.js'></script>
			<script>
				Swal.fire({
				  icon: 'error',
				  title: 'Does not exists',
				  html: 'Redirecting ...',				  
				  showConfirmButton: false,
				  timerProgressBar: true,
				  timer: 3000		  
				}).then(function() {
				     window.location.href = 'https://ollh-manila.com';
				})
			</script>
			</html>";
		}
	}	


?>
