<?php 
// Include the database config file 
include_once 'dbconn.php'; 
 
if(!empty($_POST["region"])){ 
    // Fetch state data based on the specific country
    $region = $_POST['region'];
    $query = "SELECT * FROM aprovince WHERE FK_aregion = '$region' ORDER BY description"; 
    $result = $mysqli->query($query);
    // Generate HTML of state options list 
    if($result->num_rows > 0){ 
        echo '<option value="" hidden selected>- SELECT PROVINCE -</option>'; 
        while($row = $result->fetch_assoc()){  
            echo '<option value="'.$row['province_code'].'">'.$row['description'].'</option>';             
        } 
    }else{ 
        echo '<option value="">- PROVINCE NOT AVAILABLE- </option>'; 
    } 
}elseif(!empty($_POST["province"])){ 
    $province = $_POST['province'];
    // Fetch city data based on the specific state 
    $query = "SELECT * FROM amunicity WHERE province_code = '$province' ORDER BY description";  
    $result = $mysqli->query($query); 
     
    // Generate HTML of city options list 
    if($result->num_rows > 0){ 
        echo '<option value="" hidden selected>- SELECT MUNICIPALITY -</option>'; 
        while($row = $result->fetch_assoc()){  
            echo '<option value="'.$row['PK_amunicity'].'">'.$row['description'].'</option>'; 
        } 
    }else{ 
        echo '<option value="">CITY NOT AVAILABLE</option>'; 
    } 
} 
?>