<?php
$mysqli = new mysqli("localhost","root","","livedb_expresslab");
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
// Check connection
if ($mysqli -> connect_errno) {
  echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
  exit();
}
date_default_timezone_set('Asia/Manila');
?>